# Calculadoras de Enfermagem — Unified Corpus Foundation v1.2.0

This release extends v1.1.0 with canonical **curriculum-item extraction and normalization**.

## Current canonical inventory
- Institutions: 15
- Postgraduate/residency programs: 112
- Canonical curriculum sources: 68
- Curriculum items extracted in wave 1: 320
- Programs with extracted curricular items: 27
- Sources deeply extracted in wave 1: 15
- Normalized/candidate curriculum topics: 81
- Curriculum-item → topic mappings: 478
- Topics independently supported by 2+ institutions: 30

## New files
- `curriculum/curriculum_item_registry.csv|json`
- `curriculum/curriculum_item_topic_mappings.csv|json`
- `curriculum/canonical_curriculum_topic_registry.csv|json`
- `curriculum/curriculum_source_extraction_coverage.csv|json`
- `curriculum/postgraduate_program_extraction_coverage.csv|json`
- `reports/cross_institution_topic_recurrence.csv|json`
- `reports/curriculum_extraction_wave1_summary.json`
- `schemas/curriculum_item.schema.json`

## Important
Raw titles are immutable evidence. Canonical topics are mappings, not replacements. A curriculum item proves educational discovery/relevance; clinical claims still require the scientific/normative evidence pipeline.
