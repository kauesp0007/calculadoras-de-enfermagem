# Calculadoras de Enfermagem — Unified Corpus Foundation v1.1.0

## v1.1.0 — Canonical Postgraduate Curriculum Sources
Esta versão torna o pacote a fonte canônica interna para o **corpus curricular de todas as pós-graduações e residências investigadas nesta wave**.

- instituições canônicas: **15**;
- fontes curriculares oficiais registradas: **68**;
- programas de pós/residência investigados e vinculados: **112**;
- relações programa→fonte: **153**;
- programas sem fonte oficial vinculada: **0**.

Leia também `docs/CANONICAL_CURRICULUM_SOURCE_POLICY.md` e os registries em `curriculum/`.


Fundação para unificar o melhor do corpus rights-governed de Urgência/Emergência com o Topic Universe / Canonical Content Model de Saúde do Trabalhador.

## Contagens preservadas
- fontes unificadas: **118** (84 UE + 34 Trabalho; sem colapso silencioso);
- tópicos preservados: **1055** (170 UE + 885 Trabalho);
- UE atom index: **80.261**;
- UE full-text ativo: **28.001**;
- Work claims iniciais: **29**;
- Open RN: **10 livros** no manifest de aquisição.

## Leia primeiro
1. `docs/UNIFIED_ARCHITECTURE.md`
2. `docs/RIGHTS_RETRIEVAL_POLICY.md`
3. `docs/SOURCE_ACQUISITION_STRATEGY.md`
4. `docs/COMPLETE_EXECUTION_PLAN.md`
5. `docs/DEFINITION_OF_DONE.md`
6. `plans/gates_G0_G9.json`

## Registries
- `unified_source_registry.*` — import preservado dos dois universos;
- `unified_topic_registry.jsonl` — temas preservados com origem e estado semântico;
- `source_family_seed_registry.*` — novas famílias prioritárias para expansão do corpus;
- `openrn_10_book_acquisition_manifest.json` — manifest já existente incorporado ao plano.

## Regra principal
Currículo descobre **o que precisa existir**. Corpus mostra **o que as fontes realmente contêm**. Evidence atoms sustentam **onde está a evidência**. Claims/knowledge atoms determinam **o que pode ser promovido canonicamente**. O conteúdo final é uma composição posterior.
