# Calculadoras de Enfermagem — Unified Corpus Foundation v1.5.0

## Wave 4 + evidence/resource bridge (2026-10-03)

- Programs investigated: 114 (111 in nursing scope).
- Canonical curriculum sources: 96.
- Curriculum/objective/module items: **985**.
- Programs with granular extraction: **83**.
- Nursing-scope programs still without granular public extraction: **28**.
- Normalized/candidate topics: **182**; 57 recur across 2+ institutions.
- Specialty seed registry: 181 records.
- Tool registry: 44 records.
- Library registry: 33 records.
- Source-family registry: 40 families.
- Topic→source-family acquisition requirements: 1064.
- Topic→tool/library candidate links: 376.

This version starts the controlled transition from **curriculum discovery** to **evidence acquisition + specialty resource linkage**. Candidate links are not clinical validation.

See `docs/CURRICULUM_EXTRACTION_WAVE4_AND_RESOURCE_BRIDGE.md` and `docs/CORPUS_ACQUISITION_BRIDGE.md`.

---

# Calculadoras de Enfermagem — Unified Corpus Foundation v1.4.0

## Wave 3 status (2026-10-03)

- 114 investigated program records; 111 remain in nursing scope.
- 88 canonical curriculum sources.
- 906 curriculum/objective items extracted.
- 76 programs have granular extraction; 35 nursing-scope programs remain without granular public extraction.
- 157 normalized/candidate curriculum topics; 54 recur across at least two institutions.
- Mapping-quality correction removed 54 false-positive maternal mappings caused by `materiais`/`material`.
- Non-nursing target-profession mismatches remain in the audit trail but are excluded from nursing coverage.

See `docs/CURRICULUM_EXTRACTION_WAVE3.md`.

---

# Calculadoras de Enfermagem — Unified Corpus Foundation v1.3.1

Curriculum extraction patch completing every detailed source that was pending after v1.3.0 or classifying redundant detailed sources as covered by an equivalent canonical source for the same program.

- Institutions: 15
- Programs: 114
- Canonical curriculum sources: 74
- Curriculum items: 673
- Programs with extracted items: 61
- Sources with extracted items: 50
- Detailed sources pending: 0
- Detailed sources covered by equivalent program source: 0
- Normalized/candidate topics: 120
- Cross-institution topics (2+ institutions): 47

Curriculum sources remain discovery evidence only. Clinical content still requires scientific/normative evidence and rights gates.
