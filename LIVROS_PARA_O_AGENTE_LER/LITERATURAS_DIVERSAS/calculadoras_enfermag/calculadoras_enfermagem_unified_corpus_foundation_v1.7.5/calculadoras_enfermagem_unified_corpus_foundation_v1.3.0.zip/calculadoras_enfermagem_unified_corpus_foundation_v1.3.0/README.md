# Calculadoras de Enfermagem — Unified Corpus Foundation v1.3.0

Wave 2 expands canonical postgraduate curriculum extraction while preserving all v1.2.0 provenance.

## Inventory
- Institutions: 15
- Postgraduate/residency programs: 114
- Canonical curriculum sources: 74
- Curriculum items: 581
- Items added in wave 2: 261
- Programs with extracted items: 55
- Sources with extracted items: 43
- Normalized/candidate curriculum topics: 110
- Item→topic mappings: 914
- Topics supported by 2+ institutions: 46
- Detailed sources still pending deep extraction: 7

## New source evidence
Official matrix PDFs are now canonical sources when available (for example IDOR ICU and Pesquisa Clínica). New programs discovered during the same investigation are added rather than left outside the registry.

## Boundary
Curriculum sources establish educational discovery/relevance. Clinical claims, formulas, cutoffs and care recommendations still require the normative/scientific evidence pipeline.
