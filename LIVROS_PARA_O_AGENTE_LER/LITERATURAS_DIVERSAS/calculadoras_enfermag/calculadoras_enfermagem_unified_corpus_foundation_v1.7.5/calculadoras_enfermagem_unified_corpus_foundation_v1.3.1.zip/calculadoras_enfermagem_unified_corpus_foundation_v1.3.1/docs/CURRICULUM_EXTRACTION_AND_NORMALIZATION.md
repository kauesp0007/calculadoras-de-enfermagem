# Curriculum extraction and normalization — v1.2.0

## Principle
Every published curricular item is preserved as RAW evidence and linked to the canonical institution, program and curriculum source. Normalization is a separate relation and never overwrites the raw title.

## Item types
DISCIPLINE, MODULE, SUBTOPIC, PRACTICE_COMPONENT, PRACTICE_SCENARIO and PROGRAM_OBJECTIVE.

## Normalization
Recurring cross-specialty themes are mapped to CORE topics. Specialty-specific families are mapped separately. Novel titles remain `CANDIDATE_REQUIRES_REVIEW`; no automatic lexical expansion is promoted to canonical truth.

## Provenance
`CURRICULUM_SOURCE -> POSTGRADUATE_PROGRAM -> CURRICULUM_ITEM -> TOPIC_MAPPING -> CANONICAL_TOPIC`.

## Evidence boundary
Curricular sources support topic discovery and educational relevance only. They do not by themselves support clinical claims, formulas, contraindications, thresholds or therapeutic recommendations.

## Wave 1
Deep extraction prioritised public current curricula with useful granularity from PUCPR, PUC Minas, Santa Casa de São Paulo, Hospital Moinhos de Vento and HCPA. All 68 previously investigated curriculum sources remain canonical and receive an extraction state; sources not yet deeply extracted remain explicit gaps rather than being silently inferred.
