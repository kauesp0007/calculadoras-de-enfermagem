# Canonical Curriculum Source Policy v1.0

## Mandate
Every postgraduate or residency program used for topic discovery MUST have at least one `CURRICULUM_SOURCE` from the official institution. No program may enter canonical curricular discovery only from marketing aggregators, third-party course directories, memory, or inferred curricula.

## Source precedence
1. Current official program page with published curriculum/discipline list.
2. Current official project/PPC/PDF or official notice/editing document.
3. Current official program page with objectives, competencies and scenarios.
4. Current official institutional catalog that explicitly lists the program.
5. Historical official curriculum, only with `temporal_status=HISTORICAL_OFFICIAL`.

## Detail states
- `FULL_CURRICULUM_CURRENT` — discipline/module structure is publicly recoverable.
- `PARTIAL_CURRICULUM_CURRENT` — meaningful modules/subjects are public, but not a complete matrix.
- `OBJECTIVES_AND_SCENARIOS_CURRENT` — objectives, competencies and practice scenarios are public.
- `PROGRAM_INVENTORY_CURRENT` — official call/catalog confirms the program(s).
- `PROGRAM_CONFIRMATION_CURRENT` — official institution confirms the individual program, but no usable public matrix was found in this wave.
- `CATALOG_CURRENT` — current official catalog supports discovery but requires program-level resolution before extracting a detailed curriculum.
- `HISTORICAL_OFFICIAL` — retained only for historical comparison/gap discovery.

## Hard rules
- Program title normalization NEVER overwrites the raw institutional title.
- Curriculum items extracted from a source retain `curriculum_source_id`, institution, edition/cycle and raw wording.
- One canonical topic may be supported by many curricula; one curriculum item may map to many topics.
- A course being offered does not make its curriculum a clinical authority. Curricula are discovery evidence, not clinical/normative evidence.
- Program pages and curriculum PDFs remain subject to rights review before full-text storage/atomization. Their factual metadata can be indexed independently from copyright status.

## Release gate
`G1-CURRICULUM-SOURCES` passes only when every program in `postgraduate_program_registry` has one or more rows in `program_source_relationships` and every referenced source resolves to an official institution URL.
