# Curriculum extraction — Wave 2 / v1.3.0

## Outcome
- Canonical institutions: 15
- Programs: 114
- Canonical curriculum sources: 74
- Curriculum items: 581
- New items in wave 2: 261
- Programs with extracted items: 55
- Sources with extracted items: 43
- Normalized/candidate topics: 110
- Topics supported by >=2 institutions: 46
- Detailed sources still pending: 7

## Additions
Wave 2 deepens Santa Casa (UTI, Saúde Coletiva, Gestão), Sírio-Libanês residencies and Saúde Corporativa, PUCPR (UTI, Estomaterapia, Qualidade, Oncologia multiprofissional and additional perioperative/palliative programs), IDOR (UTI matrix, Estomaterapia, TCTH, Pesquisa Clínica matrix), IPq-HCFMUSP, Instituto Dante Pazzanese, A.C.Camargo and HAOC oncology historical curriculum.

## Provenance policy
Exact published disciplines/modules are stored as extracted. When an official page publishes objectives rather than a formal discipline list, the item type is `PROGRAM_OBJECTIVE`; any normalization/paraphrase is explicitly marked `CURRENT_OFFICIAL_PARAPHRASED_OBJECTIVE`. Historical curricula remain temporal evidence and are never mislabeled as current.
