# Source Acquisition Strategy

## 1. Descoberta curricular (não é evidência clínica)
Inventariar programas de especialização, residência, graduação e especialização técnica de instituições de referência. Cada item recebe instituição, curso, nível, edição/ano, carga horária, título original, URL, snapshot e hash. O objetivo é descobrir cobertura, competências e lacunas.

## 2. Normativos brasileiros
Aquisição integral/versionada de legislação e atos oficiais relevantes: Planalto/DOU, Ministério da Saúde/Saúde Legis, ANVISA, MTE/NRs, COFEN/CORENs quando normativos. Versionar vigência, alterações, revogações e jurisdição.

## 3. OER de Enfermagem
P0: Open RN completo (10 livros do manifest atual). É a principal fundação didática reutilizável porque a coleção declara CC BY 4.0.

## 4. Literatura científica aberta
PMC OA + Europe PMC OA + SciELO. Ingestão SOMENTE após leitura da licença por artigo. Default comercial: CC0/CC BY; demais licenças seguem perfil específico. Use DOI/PMCID como chaves e preserve XML quando disponível.

## 5. Fontes governamentais/institucionais abertas
Priorizar fontes compatíveis com reutilização comercial: ILO 2023+, Safe Work Australia, HSE Crown/OGL, EU-OSHA quando autorizado, FDA e institutos NIH com texto público/sem copyright, CDC Stacks explicitamente Public Domain.

## 6. Fontes condicionais
WHO/PAHO (NC-SA), OpenStax Nursing (NC-SA e política específica para IA/comercial), Queensland/ACSQHC (ND/NC em muitos recursos), NICE (licença/API/AI approval). São excelentes para gap detection e, quando permitido, evidência; não entram automaticamente no corpus comercial.

## 7. Fontes proprietárias de alta autoridade
AHA, AAP/NRP, AORN, AAMI, ISO, INS, NANDA/NIC/NOC, SOBECC e equivalentes permanecem em `HUMAN_REFERENCE_ONLY` até licença. Servem para identificar gaps, terminologia, atualizações e conflitos; não para copiar formulários, algoritmos, tabelas ou texto.

## 8. Aquisição por especialidade
### Urgência/Emergência
Manter 84 fontes atuais; substituir gaps proprietários por Open RN, legislação BR, PMC/SciELO, WHO-BEC (condicional), CDC/NIH e artigos OA compatíveis.

### Saúde do Trabalhador
P0: atos MTE/NR, MS/PNSTT, Fundacentro/RBSO CC BY, ILO 2023+, NIOSH/CDC por item, Safe Work Australia, HSE, EU-OSHA, SciELO/PMC. WHO/PAHO ficam condicionais.

### Centro Cirúrgico / RA / CME
P0: ANVISA atos oficiais (RDCs etc.), CDC Stacks Public Domain de desinfecção/esterilização, FDA reprocessing/device safety, PMC/SciELO OA, Open RN fundamentos/skills/pharmacology. WHO SSI e publicações 2017+ ficam condicionais NC; manual WHO/PAHO de 2016 deve manter direitos específicos históricos. AORN/AAMI/SOBECC/ISO permanecem referência humana/licenciada.

### Próximas especialidades
UTI/Cardio/Pulmonar -> NHLBI + OA; Oncologia -> NCI + OA; Nefrologia/Diabetes -> NIDDK + OA; Pediatria/Neonatologia/Obstetrícia -> NICHD + OA; Geriatria -> NIA; Trauma/Ortopedia -> NIAMS + OA. Sempre cruzar com normas brasileiras e currículo.

## 9. Meta-discovery
Crossref/OpenAlex/Unpaywall/DOAJ podem descobrir documentos e metadados, mas nunca promovem full text para o corpus sem voltar à licença e à fonte original.
