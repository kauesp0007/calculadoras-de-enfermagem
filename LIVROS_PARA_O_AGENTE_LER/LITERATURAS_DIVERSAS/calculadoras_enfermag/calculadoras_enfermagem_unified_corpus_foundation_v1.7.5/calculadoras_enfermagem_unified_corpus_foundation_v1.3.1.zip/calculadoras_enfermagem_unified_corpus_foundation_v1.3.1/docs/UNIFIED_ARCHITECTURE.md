# Unified Nursing Corpus Architecture v1.0

## O que foi unificado

### Do corpus de Urgência/Emergência
- source-first acquisition;
- snapshots e hashes;
- source blocks/evidence atoms;
- FTS/SQLite;
- source-topic edges;
- direitos fail-closed;
- accountabilidade de todos os 80.261 átomos, inclusive bloqueados.

### Do Topic Universe / modelo canônico de Saúde do Trabalhador
- matriz Técnico + Graduação + Pós como descoberta curricular;
- taxonomia ampla antes da produção editorial;
- distinção `topic_inventory != atomic_knowledge`;
- `AREA > CLUSTER > CONTENT`;
- `TOOL != CONTENT`;
- claim registry e knowledge atoms;
- lifecycle normativo e page intentions como projeção, não verdade canônica.

## Cadeia canônica

```text
CURRICULUM_SOURCE -> CURRICULUM_ITEM -> TOPIC_DISCOVERY
                                  \nSOURCE -> SOURCE_VERSION -> SOURCE_BLOCK -> EVIDENCE_ATOM
                                          |
TOPIC <-> EVIDENCE_CANDIDATE -> CLAIM -> KNOWLEDGE_ATOM
                                          |
             SPECIALTY <-> CONTENT <-> TOOL <-> LIBRARY_ENTRY
                                          |
                         PUBLICATION / HTML / PDF / QUIZ / ...
```

## Regra dos átomos
- `EVIDENCE_ATOM`: o que a fonte diz, com locator/hash/rights snapshot. Imutável.
- `CLAIM`: proposição verificável criada para validação.
- `KNOWLEDGE_ATOM`: unidade canônica validada, versionada e contextualizada.

Nunca colapsar esses três objetos.

## Navegação versus conhecimento
`AREA > CLUSTER > CONTENT` continua sendo uma projeção editorial. `SPECIALTY` é plano transversal many-to-many; não é pai proprietário da ferramenta ou do conhecimento.
