# Complete Execution Plan — From Current State to Corpus Saturation

## Estado inicial preservado
- Urgência/Emergência: 84 fontes, 170 tópicos, 80.261 átomos indexados; 28.001 full-text ativos; rights fail-closed.
- Saúde do Trabalhador: 34 fontes, 32 domínios, 140 módulos, 885 tópicos, 29 claims/knowledge atoms iniciais.
- Canonical v0.2: `AREA > CLUSTER > CONTENT`, TOOL paralelo, 885 blueprints.
- Open RN expansion: manifest de 10 livros, ainda como aquisição a executar.

## Execução
1. **Não reatomizar Urgência do zero.** Migrar o corpus governado como evidence layer.
2. **Não promover os 885 tópicos de Trabalho a fatos.** Atomizar fontes e promover por claim.
3. Executar rights audit nas 34 fontes de Trabalho.
4. Executar aquisição Open RN 10 livros e validar hashes/licença/assets.
5. Criar acquisition connectors por source family (HTML/PDF/XML/API), todos com snapshot + hash + license evidence.
6. Ingerir fontes P0 comerciais/reutilizáveis e formar `SOURCE_BLOCK`/`EVIDENCE_ATOM`.
7. Criar corpus científico OA por tópico usando queries reproduzíveis, license allowlist e DOI/PMCID.
8. Rodar mapping semântico `TOPIC <-> EVIDENCE_ATOM`; gerar claim candidates, nunca páginas automaticamente.
9. Validar/promover `CLAIM -> KNOWLEDGE_ATOM`; registrar conflitos e applicability.
10. Deduplicar CORE transversal entre especialidades.
11. Importar/expandir SPECIALTY registry e linkar CONTENT/TOOL/LIBRARY many-to-many.
12. Auditar cada calculator/scale/score: origem, fórmula/itens, licença, tradução validada, população, limites.
13. Executar o mesmo pipeline para Centro Cirúrgico/CME/RA.
14. Repetir por todas as especialidades reconhecidas/benchmark até critério de saturação.
15. Somente então gerar os conteúdos editoriais e os múltiplos produtos.

## Critério de parada
Não existe “baixamos X PDFs, acabou”. Corpus fecha quando cobertura, direitos, evidência, conflito, atualização e saturação passam no `DEFINITION_OF_DONE.md`.


## G1-CURRICULUM-SOURCES — mandatory sub-gate (v1.1.0)
Before topic normalization, every investigated postgraduate/residency program must resolve through `curriculum/postgraduate_program_registry.*` → `curriculum/program_source_relationships.*` → `curriculum/curriculum_source_registry.*`. Programs without official canonical source are blocked from canonical curriculum extraction.
