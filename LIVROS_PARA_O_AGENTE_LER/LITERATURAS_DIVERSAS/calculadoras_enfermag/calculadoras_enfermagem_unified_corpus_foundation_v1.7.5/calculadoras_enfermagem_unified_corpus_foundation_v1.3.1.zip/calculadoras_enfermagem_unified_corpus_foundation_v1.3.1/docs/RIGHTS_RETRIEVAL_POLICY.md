# Rights & Retrieval Policy v1.0

## Princípio
Fail-closed. A licença é avaliada por dimensão; uma cor única é apenas resumo visual.

## Dimensões obrigatórias
`local_store`, `fulltext_ingest`, `tdm_ai`, `automated_retrieval`, `factual_claim_use`, `short_quote`, `adapt`, `translate`, `commercial_publish`, `redistribute_full_source`, `tables_figures`, `assets`, `logo_trademark`.

## Perfis de retrieval
- **R0 DEFAULT_ACTIVE** — uso comercial/adaptação/TDM compatíveis; texto pode alimentar retrieval com atribuição e restrições registradas.
- **R1 DEFAULT_ACTIVE_FACTS_ONLY** — ingestão permitida, mas saída deve ser síntese independente; expressão/assets não são reutilizáveis.
- **R2 CONDITIONAL_CONTEXT** — NC, SA, ND, restrições territoriais ou permissão específica; ativação exige profile compatível.
- **R3 HUMAN_REFERENCE_ONLY** — fonte pode orientar revisão humana e detecção de gaps/conflitos; não entra no contexto generativo.
- **R4 LICENSE_QUARANTINE** — texto protegido isolado; metadata/proveniência apenas.
- **R5 UNKNOWN_BLOCKED** — nenhuma automação até auditoria.

## Brasil
Textos de tratados, leis, decretos, regulamentos, decisões judiciais e demais atos oficiais são tratados como objetos normativos primários fora da proteção autoral prevista pela Lei 9.610/1998, art. 8º, IV. Isso NÃO se estende automaticamente a manuais, livros, ilustrações, layouts, compilações ou páginas editoriais de órgãos públicos.

## Regra comercial
Como a plataforma pode conter monetização/premium, licença `NC` não é default-active. OMS, OPAS e OpenStax entram em R2 salvo permissão ou publicação explicitamente separada em contexto não comercial compatível.
