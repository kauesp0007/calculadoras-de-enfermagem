# Definition of Done — Corpus por especialidade

Uma especialidade só recebe estado `CORPUS_SATURATED_FOR_PRODUCTION` quando TODOS os gates abaixo passam.

## Cobertura curricular
- 100% dos currículos oficiais/benchmark adquiridos estão versionados e mapeados ou possuem gap documentado.
- >=99% dos conceitos curriculares normalizados possuem `TOPIC` canônico ou decisão `OUT_OF_SCOPE` justificada.
- Técnico, Graduação e Pós são projeções de competência/profundidade; não duplicações do conhecimento.

## Cobertura de evidência
- Todo tópico P0/segurança possui ao menos uma fonte primária/autoridade vigente.
- Claim clínico de alto risco: mínimo 2 suportes independentes quando disponíveis, sendo ao menos 1 diretriz/consenso/revisão/órgão oficial atual.
- Claim normativo brasileiro: fonte primária oficial vigente obrigatória.
- Medicamentos, doses, limites e condutas tempo-críticas recebem dupla validação e freshness mais curto.

## Direitos
- 100% das fontes classificadas em todas as dimensões de uso.
- Nenhum `UNKNOWN` no índice ativo.
- Nenhuma tabela, figura, escala, formulário, taxonomia ou asset de terceiro é liberado por herança da licença do documento.
- Fontes NC/ND/proprietárias ficam fora do índice gerativo comercial salvo permissão explícita.

## Saturação
- Executar ondas sucessivas de descoberta. Parar apenas após 3 ondas consecutivas com <2% de novos conceitos canônicos E <1% de novos gaps P0.
- Não usar número absoluto de páginas como critério de conclusão.

## Consistência
- `SOURCE -> EVIDENCE_ATOM -> CLAIM -> KNOWLEDGE_ATOM -> CONTENT/PUBLICATION` reversível.
- 0 conflitos críticos não resolvidos.
- 0 claims órfãos.
- 0 knowledge atoms sem claim.
- 0 publicações sem claims específicos.

## Freshness
- Normas e fontes dinâmicas possuem `effective_date`, `verified_on` e `review_policy`.
- Alteração normativa dispara invalidação/revisão das relações dependentes.

## Produto
- Conteúdo somente é `PUBLISH_READY` após evidência, direitos, revisão editorial, segurança clínica, acessibilidade, SEO e integridade de links/hashes.
