# Public Curriculum Detail Resolution Policy — v1.6.0

## Purpose
Close curriculum discovery without fabricating hidden or unpublished course matrices.

A postgraduate program is not kept indefinitely as “pending” when the current official institution source confirms the program but the public curriculum is unavailable, unindexed, or explicitly restricted. Instead it receives an explicit public-detail resolution.

## States

- `CURRICULUM_OR_OBJECTIVES_EXTRACTED`: public official curriculum, modules, objectives or competencies were extracted.
- `CURRENT_PROGRAM_CONFIRMED_NO_PUBLIC_GRANULAR_CURRICULUM_EXPOSED`: current official offering confirmed; no granular public matrix found after targeted official-source search.
- `CURRENT_CATALOG_CONFIRMED_NO_PUBLIC_GRANULAR_CURRICULUM_EXPOSED`: current catalog confirms offering; no public detailed curriculum found.
- `CURRENT_PROGRAM_CONFIRMED_DETAIL_RESTRICTED_TO_ENROLLED_RESIDENTS`: institution explicitly restricts detailed contents to enrolled students/residents.
- `CURRENT_MULTIPROFESSIONAL_NURSING_AREA_CONFIRMED_NO_PROGRAM_SPECIFIC_PUBLIC_CURRICULUM`: institution confirms Nursing as a lato-sensu area but does not publicly expose a program-specific matrix.
- `EXCLUDED_FROM_NURSING_SCOPE`: investigated program is retained in provenance but excluded from the nursing curriculum denominator.
- `ACTIVE_SEARCH_PENDING`: true unresolved case; release gate requires this to be zero for the investigated set.

## Non-inference rule
Catalog facets, marketing descriptions, specialty names, another profession’s curriculum, or historical curricula are never silently converted into a current curriculum. Historical official material may be retained only with explicit temporal status.

## Result for investigated corpus on 2026-10-03
The 28 previously unresolved nursing-scope programs are now explicitly resolved as public-detail unavailable/restricted rather than fabricated. `ACTIVE_SEARCH_PENDING = 0` for the 114-program investigated set.
