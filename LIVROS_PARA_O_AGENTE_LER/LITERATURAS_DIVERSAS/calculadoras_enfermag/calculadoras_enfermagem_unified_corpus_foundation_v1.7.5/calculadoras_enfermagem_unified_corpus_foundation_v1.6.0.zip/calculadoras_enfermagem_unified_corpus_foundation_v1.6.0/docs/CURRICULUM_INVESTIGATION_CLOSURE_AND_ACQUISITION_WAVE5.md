# Curriculum Investigation Closure + Acquisition Wave 5 — v1.6.0

## Closure

- Investigated program records: 114.
- Nursing-scope programs: 111.
- Programs with public extracted curriculum/objectives/items: 83.
- Programs explicitly resolved as no-public/restricted granular detail: 28.
- True active curriculum-search pending: 0.

No catalog facet, marketing description, historical curriculum or another profession's syllabus was promoted as a current nursing curriculum.

## Restricted/public-detail findings

- Einstein: current official offerings remain canonically recorded; public indexed pages reviewed do not expose sufficiently granular curricula for the remaining 17 programs.
- HAOC: current catalog confirms the remaining 5 offerings/families; no granular nursing curriculum was substituted from unrelated or medical material.
- IFF/Fiocruz: institution explicitly states detailed ementas/grades/rotations are available only to enrolled residents; all 5 programs are therefore marked `DETAIL_RESTRICTED_TO_ENROLLED_RESIDENTS`.
- InCor: official education page confirms Nursing as a lato-sensu multiprofessional area; no program-specific public nursing matrix was identified.

## Acquisition execution scaffold

The canonical topic→source-family queue is now executable in controlled P0 batches. `rights_preflight_P0.csv` applies family-level conservative gating; per-item license resolution remains mandatory where the family is article/book/document-specific.

Scripts: `scripts/validate_foundation.py`, `scripts/build_acquisition_batches.py`, `scripts/rights_preflight.py`.
