from pathlib import Path
import pandas as pd, json, sys

ROOT = Path(__file__).resolve().parents[1]
errors=[]
warnings=[]
checks=[]

def read(rel):
    p=ROOT/rel
    if not p.exists():
        errors.append(f'missing file: {rel}')
        return pd.DataFrame()
    try:
        return pd.read_csv(p,dtype=str).fillna('')
    except Exception as e:
        errors.append(f'cannot read {rel}: {e}')
        return pd.DataFrame()

def unique(rel,col):
    d=read(rel)
    if d.empty:
        return d
    if col not in d.columns:
        errors.append(f'missing column {col} in {rel}; columns={list(d.columns)}')
        return d
    dup=d.loc[d[col].duplicated(keep=False) & d[col].ne(''), col].unique().tolist()
    checks.append({'check':'unique','file':rel,'column':col,'rows':len(d),'duplicates':len(dup)})
    if dup:
        errors.append(f'duplicate {col} in {rel}: {dup[:10]}')
    return d

def fk(df, col, allowed, label, allow_blank=False):
    if df.empty:
        return
    if col not in df.columns:
        errors.append(f'missing FK column {col} in {label}')
        return
    vals=set(df[col].astype(str))
    if allow_blank:
        vals.discard('')
    bad=sorted(v for v in vals if v not in allowed and v!='')
    checks.append({'check':'fk','label':label,'column':col,'distinct_values':len(vals),'unknown':len(bad)})
    if bad:
        errors.append(f'unknown {col} in {label}: {bad[:10]}')

prog=unique('curriculum/postgraduate_program_registry.csv','program_id')
src=unique('curriculum/curriculum_source_registry.csv','curriculum_source_id')
item=unique('curriculum/curriculum_item_registry.csv','curriculum_item_id')
topic=unique('curriculum/canonical_curriculum_topic_registry.csv','topic_id')
tool=unique('registries/tool_registry.csv','id')
lib=unique('registries/library_registry.csv','id')
spec=unique('registries/specialty_registry.csv','id')
inst=unique('curriculum/institution_registry.csv','institution_id')

ps=set(prog.get('program_id',[])); ss=set(src.get('curriculum_source_id',[])); its=set(item.get('curriculum_item_id',[])); ts=set(topic.get('topic_id',[])); tools=set(tool.get('id',[])); libs=set(lib.get('id',[])); specs=set(spec.get('id',[])); insts=set(inst.get('institution_id',[]))

rels=read('curriculum/program_source_relationships.csv')
fk(rels,'program_id',ps,'program_source_relationships')
fk(rels,'curriculum_source_id',ss,'program_source_relationships')

if not prog.empty:
    fk(prog,'institution_id',insts,'postgraduate_program_registry')

maps=read('curriculum/curriculum_item_topic_mappings.csv')
fk(maps,'curriculum_item_id',its,'curriculum_item_topic_mappings')
fk(maps,'topic_id',ts,'curriculum_item_topic_mappings')

tr=read('registries/topic_resource_candidate_links.csv')
fk(tr,'topic_id',ts,'topic_resource_candidate_links')
if not tr.empty:
    for i,r in tr.iterrows():
        typ=r.get('resource_type','')
        rid=r.get('resource_id','')
        allowed = tools if typ=='TOOL' else libs if typ=='LIBRARY' else set()
        if not allowed:
            errors.append(f'unknown resource_type {typ!r} in topic_resource_candidate_links row {i+2}')
        elif rid not in allowed:
            errors.append(f'unknown resource_id {rid!r} for {typ} in topic_resource_candidate_links row {i+2}')

sr=read('registries/specialty_resource_candidate_links.csv')
if not sr.empty:
    fk(sr,'regulatory_specialty_id',specs,'specialty_resource_candidate_links')
    # derived_via_topic_id points to canonical curriculum topics.
    fk(sr,'derived_via_topic_id',ts,'specialty_resource_candidate_links')
    for i,r in sr.iterrows():
        typ=r.get('resource_type','')
        rid=r.get('resource_id','')
        allowed = tools if typ=='TOOL' else libs if typ=='LIBRARY' else set()
        if not allowed:
            errors.append(f'unknown resource_type {typ!r} in specialty_resource_candidate_links row {i+2}')
        elif rid not in allowed:
            errors.append(f'unknown resource_id {rid!r} for {typ} in specialty_resource_candidate_links row {i+2}')

cw=read('registries/specialty_regulatory_crosswalk.csv')
if not cw.empty:
    fk(cw,'regulatory_specialty_id',specs,'specialty_regulatory_crosswalk')

# Public-detail closure invariants.
resolution=read('reports/program_public_detail_resolution.csv')
pending=read('reports/pending_curriculum_deep_extraction.csv')
active_prog = prog[prog.get('investigation_status','').ne('EXCLUDED_TARGET_PROFESSION_MISMATCH')] if not prog.empty and 'investigation_status' in prog.columns else prog
if not resolution.empty:
    closed=set(resolution.loc[resolution.get('search_resolution','').eq('CLOSED'),'program_id'])
    extracted=set(item.get('program_id',[])) if 'program_id' in item.columns else set()
    active=set(active_prog.get('program_id',[]))
    unresolved=sorted(active - extracted - closed)
    checks.append({'check':'curriculum_closure','active_programs':len(active),'with_items':len(active & extracted),'resolved_no_public_detail':len(active & closed),'unresolved':len(unresolved)})
    if unresolved:
        errors.append(f'active nursing programs neither extracted nor resolved: {unresolved[:10]}')
if not pending.empty and len(pending)>0:
    # In v1.6.0 pending file is expected to be empty or explicitly all CLOSED/none.
    if 'search_resolution' in pending.columns:
        open_rows=pending[pending['search_resolution'].ne('CLOSED')]
    else:
        open_rows=pending
    if len(open_rows):
        errors.append(f'pending curriculum deep extraction still has {len(open_rows)} open rows')

# Required JSON reports must parse.
for rel in ['reports/current_state.json','reports/curriculum_investigation_closure_and_acquisition_wave5_summary.json','plans/gates_G0_G9.json']:
    p=ROOT/rel
    try:
        json.loads(p.read_text(encoding='utf-8-sig'))
        checks.append({'check':'json_parse','file':rel,'status':'PASS'})
    except Exception as e:
        errors.append(f'invalid json {rel}: {e}')

report={
    'package':'calculadoras_enfermagem_unified_corpus_foundation_v1.6.0',
    'status':'PASS' if not errors else 'FAIL',
    'errors':errors,
    'warnings':warnings,
    'checks':checks,
    'counts':{
        'institutions':len(inst), 'programs':len(prog), 'sources':len(src), 'items':len(item), 'topics':len(topic),
        'tools':len(tool), 'libraries':len(lib), 'specialties':len(spec),
        'program_source_relationships':len(rels), 'item_topic_mappings':len(maps),
        'topic_resource_candidate_links':len(tr), 'specialty_resource_candidate_links':len(sr),
        'public_detail_resolution_rows':len(resolution), 'pending_curriculum_rows':len(pending)
    }
}
print(json.dumps(report,ensure_ascii=False,indent=2))
# Write report even when failed.
out=ROOT/'reports/foundation_validation_v1.6.0.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
sys.exit(1 if errors else 0)
