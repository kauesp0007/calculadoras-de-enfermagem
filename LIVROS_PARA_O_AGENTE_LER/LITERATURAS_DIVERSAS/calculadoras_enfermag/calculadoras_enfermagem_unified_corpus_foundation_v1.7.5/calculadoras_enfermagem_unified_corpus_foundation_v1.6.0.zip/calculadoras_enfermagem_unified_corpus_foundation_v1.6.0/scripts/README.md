# Acquisition scripts

These scripts prepare and validate controlled acquisition batches from the canonical queue. They do not override source-family rights rules and do not bulk-scrape proprietary sources.

1. `validate_foundation.py` — validates IDs/references/basic invariants.
2. `build_acquisition_batches.py` — splits `topic_evidence_acquisition_queue.csv` by priority/source family.
3. `rights_preflight.py` — joins queue with source-family rights policy and blocks non-default/unknown families from active ingestion.

Full-text adapters must preserve source version, URL, retrieval timestamp, license snapshot and content hash before atomization.
