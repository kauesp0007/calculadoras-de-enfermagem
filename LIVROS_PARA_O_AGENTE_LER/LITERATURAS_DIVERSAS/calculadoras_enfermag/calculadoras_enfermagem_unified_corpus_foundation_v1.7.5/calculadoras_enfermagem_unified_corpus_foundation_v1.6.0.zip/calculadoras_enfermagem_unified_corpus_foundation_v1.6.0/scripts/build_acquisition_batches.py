from pathlib import Path
import pandas as pd, argparse
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(); ap.add_argument('--priority',default=None); ap.add_argument('--out',default=str(ROOT/'acquisition/batches')); args=ap.parse_args()
q=pd.read_csv(ROOT/'acquisition/topic_evidence_acquisition_queue.csv',dtype=str).fillna('')
if args.priority: q=q[q.priority.eq(args.priority)]
out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
for (priority,family),g in q.groupby(['priority','source_family_id']):
    safe=f'{priority}__{family}.csv'.replace('/','_'); g.to_csv(out/safe,index=False)
print(f'wrote {q.groupby(["priority","source_family_id"]).ngroups} batches / {len(q)} acquisition tasks to {out}')
