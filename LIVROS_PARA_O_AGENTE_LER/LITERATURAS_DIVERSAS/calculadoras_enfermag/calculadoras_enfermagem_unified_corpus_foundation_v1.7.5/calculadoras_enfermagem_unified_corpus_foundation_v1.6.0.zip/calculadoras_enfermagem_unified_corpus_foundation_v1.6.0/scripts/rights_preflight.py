from pathlib import Path
import pandas as pd, argparse
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(); ap.add_argument('--priority',default='P0'); ap.add_argument('--out',default=str(ROOT/'acquisition/rights_preflight.csv')); args=ap.parse_args()
q=pd.read_csv(ROOT/'acquisition/topic_evidence_acquisition_queue.csv',dtype=str).fillna('')
f=pd.read_csv(ROOT/'registries/source_family_seed_registry.csv',dtype=str).fillna('')
d=q.merge(f,left_on='source_family_id',right_on='id',how='left',suffixes=('','_family'))
if args.priority: d=d[d.priority.eq(args.priority)]
# This is deliberately conservative. Per-item families remain CHECK_REQUIRED until item license is resolved.
def gate(r):
    rm=r.get('rights_mode','')
    if rm.startswith('DEFAULT_ACTIVE'): return 'FAMILY_PRECHECK_PASS_ITEM_EXCEPTIONS_STILL_APPLY'
    if rm in ('LICENSE_FILTER_REQUIRED','PER_ARTICLE_LICENSE_CHECK','PER_BOOK_LICENSE_CHECK','PER_DOCUMENT_RIGHTS_CHECK'): return 'ITEM_RIGHTS_CHECK_REQUIRED'
    return 'BLOCK_FROM_ACTIVE_INGEST_UNTIL_RIGHTS_RESOLVED'
d['preflight_gate']=d.apply(gate,axis=1)
Path(args.out).parent.mkdir(parents=True,exist_ok=True); d.to_csv(args.out,index=False)
print(d.preflight_gate.value_counts().to_string())
