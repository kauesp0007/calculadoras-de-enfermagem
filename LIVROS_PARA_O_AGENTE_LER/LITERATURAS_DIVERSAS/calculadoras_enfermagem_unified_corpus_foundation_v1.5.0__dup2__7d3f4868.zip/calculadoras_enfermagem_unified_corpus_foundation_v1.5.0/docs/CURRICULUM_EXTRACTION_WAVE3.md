# Curriculum Extraction Wave 3 — v1.4.0

Verified: 2026-10-03

## Scope

This wave deepens canonical postgraduate curriculum provenance and corrects normalization noise before further expansion.

## Main results

- Curriculum sources: **88**
- Program records investigated: **114**
- Active nursing-scope programs: **111**
- Programs with extracted curriculum/objective items: **76**
- Active nursing programs still without granular public extraction: **35**
- Curriculum items: **906**
- Item→topic mappings: **1383**
- Canonical/normalized/candidate topics: **157**
- Topics with support from ≥2 institutions: **54**

## Added/deepened institutions

- Santa Casa de São Paulo: Estomaterapia, Cardiologia/Hemodinâmica, Nefrologia, Oftalmologia, Oncologia, Gerontologia, Ciências Forenses, Obstetrícia Crítica and Pediatria Crítica.
- PUCPR: Enfermagem Oncológica, Enfermagem Gerontológica, Gestão em Saúde/Enfermagem, Terapia Infusional/Acessos Venosos, Cuidados Intensivos Neonatais e Pediátricos.
- HAOC/FECS: historical complete program content for Gerenciamento e Liderança em Enfermagem, explicitly marked historical.

## Quality correction

The previous normalized rule for `SPTOP-MATERNAL` had a substring collision: `mater...` also matched `materiais`. This wave removed **54** false-positive mappings and replaced the matcher with strict maternal/obstetric terminology.

## Scope correction

Three A.C.Camargo programs previously catalogued under nursing were verified as targeted to other professions and are now retained only as investigated/out-of-nursing-scope records. No records were silently deleted.
