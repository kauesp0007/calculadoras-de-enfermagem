# Curriculum Extraction Wave 4 + Resource Bridge — v1.5.0

Verified: 2026-10-03

## What changed

- Added 8 canonical curriculum sources.
- Added 79 curriculum/objective/module items.
- Total curriculum items: 985.
- Programs with extracted curriculum/objectives: 83.
- Active nursing-scope programs still without granular public detail: 28.
- Canonical/candidate topics: 182.
- Topics supported by 2+ institutions: 57.

## High-value closures

1. **PUCPR Pediatria** — current official 360 h curriculum, 16 disciplines.
2. **Fiocruz Brasília** — official selection notice for the 2026 cohort provides objectives/scenarios for Atenção Básica, Vigilância em Saúde and Saúde da Família do Campo; current 2026 module reports deepen the Campo curriculum.
3. **A.C.Camargo MBA Gestão em Saúde com Ênfase em Ambientes Complexos** — current multiprofessional program, applicable to nurses; 432 h and current management competencies.
4. **HAOC ICU and Gerontology** — current program presence remains catalog-confirmed; historical 2015 official objectives were added with explicit historical status, never presented as current curriculum.

## Resource bridge

Imported governed seeds from v0.3.2:

- specialties: 181
- tools/calculators/scales/scores: 44
- libraries: 33

Added discovery candidates from the U/E corpus: MEWS, SIRS, anion gap, acid-base compensation, RTS, ISS, TRISS, Rule of Nines, Lund-Browder and pediatric dose-by-weight. All remain pending tool-level evidence/rights validation.

**The old 20k+ automatically generated specialty-resource relations were intentionally not imported.** New relations are topic-driven candidates and must pass evidence/rights gates.

## Evidence acquisition bridge

- source families: 40
- topic→source-family requirements: 1064
- topic→tool/library candidate links: 376
- acquisition queue rows: 1064

No row in this queue claims that evidence has already been acquired. It is a governed acquisition plan.

## Specialty linkage layer

- Curriculum specialty IDs observed in postgraduate programs: 52.
- Curriculum↔regulatory crosswalk rows: 57.
- Specialty↔tool/library candidate relations derived through curriculum topics: 2073.

The crosswalk is intentionally non-destructive. Institutional profiles such as robotic surgery, navigation, patient safety or cellular therapy can remain internal profiles even when COFEN has no exact one-to-one specialty label.
