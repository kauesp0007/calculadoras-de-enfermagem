# Corpus Acquisition Bridge — v1.5.0

## Purpose

Turn the curriculum-derived topic universe into a real evidence corpus without lexical fabrication.

## Canonical flow

CURRICULUM_ITEM → TOPIC → ACQUISITION_REQUIREMENT → SOURCE_VERSION → EVIDENCE_ATOM → CLAIM → KNOWLEDGE_ATOM → CONTENT → PUBLICATION

## Discovery vs reuse

PubMed/MEDLINE, BVS/LILACS and DOAJ are discovery/metadata layers. They do **not** grant blanket rights to the linked full text. Every acquired full-text source must resolve its own license/rights record before entering R0/R1 retrieval.

## Current source-family layers

- Open-first scientific: PMC OA, Europe PMC OA, SciELO, Open RN.
- Brazilian primary normative: official acts, with government manuals separately rights-reviewed.
- Specialty public authorities: CDC PD where explicit, FDA, NIH institutes, Fundacentro/RBSO.
- International occupational: ILO, Safe Work Australia, HSE, EU-OSHA.
- Conditional global guidance: WHO/PAHO/OpenStax according to license/context.
- Human-reference/proprietary: NICE where licensing restricts use; AHA/AAP/AORN/AAMI/INS/NANDA/NIC/NOC/ISO/ABNT/SOBECC; Cochrane/JBI by default.

## Next execution

1. Execute `acquisition/topic_evidence_acquisition_queue.csv` by priority.
2. Resolve rights before saving fulltext to the active retrieval corpus.
3. Atomize only versioned, hashed source snapshots.
4. Promote claims independently of curriculum recurrence.
5. Connect validated tools and library entries only after their own evidence/rights gates.
