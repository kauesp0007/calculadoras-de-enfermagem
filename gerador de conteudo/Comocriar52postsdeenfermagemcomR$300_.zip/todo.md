- [ ] Definir categorias de postagens (calculadoras, escalas, dicas gerais, etc.)
- [ ] Distribuir as 52 postagens entre as categorias
- [ ] Para cada postagem, definir um título/tema e um breve resumo do conteúdo
- [ ] Garantir que haja uma boa mistura de calculadoras e escalas
- [ ] Incluir chamadas para ação (CTAs) para o site www.calculadorasdeenfermagem.com.br


